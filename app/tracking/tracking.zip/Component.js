sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("gisamdg.tracking.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map