sap.ui.define([],function(){"use strict";return{onBackToGenerator:function(){window.location.href="/generator/webapp/index.html"}}});
//# sourceMappingURL=TrackingActions.js.map